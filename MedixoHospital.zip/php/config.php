<?php

// Twilio Credentials
$accountSid = 'ACa8784d71448ba199a111e11d23e65834';
$authToken = 'f14ddc1479530392ea3da6d71bd7a8f5';
$twilioNumber = '+14849898591';

?>
